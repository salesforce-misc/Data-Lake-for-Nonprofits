# Data Lake for Nonprofit Cloud, Powered by Amazon Web Services

See the `docs/` folder for more in depth documentation.
