# Web UI

```
npm start
npm test
npm run build
```
