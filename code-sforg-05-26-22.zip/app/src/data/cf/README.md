This folder hosts the cloudformation templates that are brought from the /infra/cf. This is done by the copy-cf.ts script.

The content of this folder should not be committed to git, this folder content is added to the .gitignore file