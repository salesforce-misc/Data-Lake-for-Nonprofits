# Step Function Lambdas

## Development Flow

Assuming your installation ID is your usename, run the following:

```
$ npm install && ./upload.sh $(whoami)
```
